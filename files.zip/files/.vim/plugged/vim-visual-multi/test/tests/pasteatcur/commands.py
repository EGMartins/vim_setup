# paste at cursor position
L = '\\\\\\\\'

keys('vip\<C-V>$y')
keys('vip' + L + 'c')
keys('f_p')
keys('a')
keys('Hello')
keys('\<Esc>')
