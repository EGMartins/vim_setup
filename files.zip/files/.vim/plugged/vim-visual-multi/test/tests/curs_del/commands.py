# delete operations at cursors
L = '\\\\\\\\'

keys('j0')
keys('5\<C-Down>ww')
keys('dWbP')
keys('5W'+L+'a')
keys('wllb'+L+'a')
keys('Bd2l')
keys('d4h')
keys('\<Esc>')
